#!/bin/bash
#SBATCH -p paratera
#SBATCH -N 1 -n 24

# Library
source /WORK/app/intel/parallel_studio_xe_2018/compilers_and_libraries_2018.0.128/linux/mkl/bin/mklvars.sh intel64
export PATH=$PATH:/WORK/app/MPI/Intel/MPICH/3.2-icc2018-dyn/bin 
export CPATH=$CPATH:/WORK/app/MPI/Intel/MPICH/3.2-icc2018-dyn/include 
export FPATH=$FPATH:/WORK/app/MPI/Intel/MPICH/3.2-icc2018-dyn/include 
export MANPATH=$MANPATH:/WORK/app/MPI/Intel/MPICH/3.2-icc2018-dyn/share/man 
export LIBRARY_PATH=$LIBRARY_PATH:/WORK/app/MPI/Intel/MPICH/3.2-icc2018-dyn/lib 
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/WORK/app/MPI/Intel/MPICH/3.2-icc2018-dyn/lib 

# QE dir
export PATH=$PATH:/HOME/pp282/WORKSPACE/apps/QE/bin

##################################################################
# Here the real job starts
echo "#--- Job started at `date`"
# Now run the program
yhrun -N 1 -n 24 pw.x < scf.in > scf.out
yhrun -N 1 -n 24 pw.x < bp.in > bp.out
echo "#--- Job ended at `date`"
##################################################################

