cd scf
mpiexec -np 48 vasp_std | tee log
cd ../
cp scf/WAVECAR scf/CHGCAR wannier_AO
cp scf/WAVECAR scf/CHGCAR wannier_MO

cd wannier_AO
mpiexec -np 48 vasp_std | tee log
mpiexec -np 48 wannier90.x wannier90 | tee wannier90.log
cd ../

cd wannier_MO
mpiexec -np 48 vasp_std | tee log
mpiexec -np 48 wannier90.x wannier90 | tee wannier90.log
cd ../

cp wannier_AO/wannier90_u.mat woops/wannier90_u_AO.mat
cp wannier_AO/wannier90_tb.dat woops/wannier90_tb.dat
cp wannier_MO/wannier90_u.mat woops/wannier90_u_MO.mat

cd woops
python woops.py | tee log
cd ../

