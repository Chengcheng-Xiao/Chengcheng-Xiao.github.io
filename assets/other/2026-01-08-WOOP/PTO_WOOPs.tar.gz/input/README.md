first export path to VASP and wannier90
export PATH=$PATH:/path/to/vasp/bin
export PATH=$PATH:/path/to/wannier90/bin

then run the following commands in sequence:
cd CENT
bash run.sh
cd ../FE
bash run.sh
cd ../analyse
bash run.sh
