cp ../CENT/woops/WAN_MAT.h5 WAN_MAT_CENT.h5
cp ../FE/woops/WAN_MAT.h5 WAN_MAT_FE.h5
python get_z.py
