from ase.calculators.vasp import VaspChargeDensity
import numpy as np
import matplotlib.pyplot as plt

#%%
def gradient(potl, delta):
    '''
    Calculate the gradient of potl at each point
    '''
    result = np.zeros([3]+list(potl.shape))
    da = (np.roll(potl,-1,0)-np.roll(potl,1,0))/delta[0]
    db = (np.roll(potl,-1,1)-np.roll(potl,1,1))/delta[1]
    dc = (np.roll(potl,-1,2)-np.roll(potl,1,2))/delta[2]
    result[0,:]=da
    result[1,:]=db
    result[2,:]=dc

    return result

def grad_rho_to_cart_abs(grad_rho, g_mat):
    '''
    transform grad_rho to cart coord and take the mod of it at each point.
    '''
    grad_rho_cart = np.zeros(grad_rho.shape)

    for a in range(3):
        grad_rho_cart[a]=np.tensordot(g_mat[:,a],grad_rho,axes=(0,0))

    grad_rho_abs = np.sqrt(grad_rho_cart[0]**2\
                          +grad_rho_cart[1]**2\
                          +grad_rho_cart[2]**2)

    return grad_rho_abs

def hessian(potl, delta):
    '''
    Calculate the hessian in direct coordinates

    delta: list : delta along each axis
    potl: np.array: data

    result: np.array : hessian at each point
    '''
    result = np.zeros([3,3]+list(potl.shape))
    for a1 in range(3):
        for a2 in range(3):
            result[a1,a2]=  (np.roll(potl,(-1,-1),axis=(a1,a2))  \
                           - np.roll(potl,(-1,+1),axis=(a1,a2))  \
                           - np.roll(potl,(+1,-1),axis=(a1,a2))  \
                           + np.roll(potl,(+1,+1),axis=(a1,a2))) \
                           / (4*delta[a1]*delta[a2])
    return result

def hess_to_cart(hess, g_mat):
    '''
    convert hessian to cart. coord
    '''
    hess_cart = np.zeros(hess.shape)
    for a in range(3):
        for b in range(3):
            hess_cart[a,b]=np.tensordot(\
                           g_mat[:,b],np.tensordot(g_mat[a,:],hess,axes=(0,0)) \
                           ,axes=(0,0))
    return hess_cart

#%% read-in data (water dimer)
vasp_charge = VaspChargeDensity(filename = 'CHGCAR')
potl = vasp_charge.chg[-1]
atoms = vasp_charge.atoms[-1]

#% calculate hessian in direct coordinates
diff = np.divide([1,1,1],potl.shape)

#% get recripocal lattice
g_mat = np.linalg.inv(atoms.cell)


#% calculate the DORI
#        (       ( \nabla rho )^2)^2
#        |\nabla | -----------|  |
#        (       (    rho     )  )
# phi   = -----------------------------
#           ( \nabla rho )^6
#           | -----------|
#           (    rho     )
#
#          DORI = phi/(1+phi)

grad_rho = gradient(potl, diff)
grad_rho_abs = grad_rho_to_cart_abs(grad_rho, g_mat)

drho_over_rho = grad_rho_abs/potl

temp1 = gradient(drho_over_rho**2, diff)
temp1_abs = grad_rho_to_cart_abs(temp1, g_mat)

phi = temp1_abs**2/drho_over_rho**6
DORI = phi/(1+phi)

# <ake sure the noise from the low density area are cleared.
DORI[potl<1E-3] = 0

#%% print the max value
print(f'Max DORI: {DORI.max()}')

#%% write sign(hess)*rho(r)
# convert DORI for plotting (ASE assumes everything is CHGCAR...)
DORI /= atoms.get_volume()
# plot
vasp_charge.chg=[DORI]
vasp_charge.write(filename='ELFCAR_DORI.vasp', format='CHGCAR')
