import numpy as np
import matplotlib.pyplot as plt

import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt
from mpl_toolkits.axes_grid1 import make_axes_locatable

# use the following to reset style
mpl.rcParams.update(mpl.rcParamsDefault)

# use mystyle and set dpi to 300
plt.style.use('publication')
mpl.rcParams['figure.dpi']= 300


#%%
time = np.linspace(0,12,1000)
data = np.sin(time)

#%% plot sin functions
fig, ax = plt.subplots(figsize=[5,4])
ax.plot(time, data)
ax.hlines(0,time.min(),time.max(), ls='--', color='tab:gray')
ax.set_xlim([time.min(),time.max()])
ax.set_xlabel('Time [s]')
ax.set_ylabel('Sin(t)')
plt.savefig('sin.svg',bbox_inches='tight')
plt.close()

#%% calculate the autocorrelation functions.
#cor = np.correlate(data, data)
cor = np.correlate(data, data, mode='full')
# shift the correlation function to start from 0.
cor = cor[len(data)-1:]
# nromalize the correlation function
cor = cor/cor.max()

fig, ax = plt.subplots(figsize=[5,4])
#scale = cor.max()/data.max()
ax.plot(time, cor)
#ax.plot(time-np.pi/2, data*scale)
xlim = ax.get_xlim()
ax.hlines(0,xlim[0],xlim[1], ls='--', color='tab:gray')
ax.set_xlim([time.min(),time.max()])
ax.set_xlabel('Time [s]')
ax.set_ylabel('Correlation')
#  ax.set_xlim([0,10])
plt.savefig('sin_cor.svg',bbox_inches='tight')
plt.close()


