1. run DFT calculations to get structure and phonon using DFPT.
2. run MD in `thermalization` to get thermalization.
3. run MD in `eq` to get equalized `XDATCAR`.
4. run `xdat2vdat.pl` to get the velocity file `VDATCAR`.
5. run `vacf.py` to get phonon DOS.

