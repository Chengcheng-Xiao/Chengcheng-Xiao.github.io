import re
import numpy as np
import matplotlib.pyplot as plt

#%% read-in velocity (Å/fs)
with open('VDATCAR', 'r') as f:
    orig_data=f.readlines()

tmp = [line for line in orig_data if line.strip()]
data = np.array([line.strip().split() for line in tmp[8:] \
                 if not re.search('[a-zA-Z]', line)],dtype=float)

#%% input
NATM = 3    # number of atoms
NT   = 6000 # number of MD runs
dT   = 0.5  # timestep [in fs]

#%% reshape to [timestep,atom_number,coord.]
data = data.reshape([int(data.shape[0]/NATM),-1,3])

#%% get VACF
def autocorr(x):
    '''
    numpy's correlation method
    see: https://stackoverflow.com/a/676302/12660859
    '''
    result = np.correlate(x, x, mode='full')
    return result[len(x)-1:]

def vacf(data, t, atm):
    '''
    manually calculate VCAF
    this routine gives more flexibility to perform dot product in 3D space.
    '''
    data1 = np.zeros(data.shape)
    data1[:data.shape[0]-t] = data[t:]
    # perform dot product to get vacf for each atom
    return (data[:,atm,:]*data1[:,atm,:]).sum(axis=-1).sum(axis=-1)


#%% append all vacf for each data
vacf_dat=[[],[],[]]
for time in range(NT-1):
    for atm in range(NATM):
        vacf_dat[atm].append(vacf(data, time, atm))
#
vacf_dat = np.array(vacf_dat,dtype=float)

#%% plot VACF
# plt.plot(range(NT-1),vacf_dat[2])
# plt.savefig('vacf.png')
# plt.close()
# plt.show()

#%% finite difference result [in THz]
DFT_result = [114.657899,
             111.218277,
              47.547363,
               2.700711,
               1.684662,
               0.440509,
              -0.465758,
              -0.661642,
              -0.847483]
# plt.scatter(DFT_result,np.ones(len(DFT_result)))
# plt.show()

#%% FT to get pho_DOS (slower)
# def pho_DOS(vacf,omega,dt,NT):
#     # unit conversion
#     omega = omega*1E12 # omega in THz
#     dt = dt*1E-15      # time in s
#     # np.fft doesn't dot the final dt.
#     return (vacf*np.exp(1j*2*np.pi*omega*(np.arange(NT-1)*dt))).sum()*dt
# #%
# NO = NT-1
# maxpoint = 1000.
#
#
# DOS_tot = []
# for atm in range(NATM):
#     DOS = []
#     for omega in np.linspace(0,maxpoint,NO):
#         DOS.append(pho_DOS(vacf_dat[2],omega,dT,NT))
#     DOS = np.array(DOS)
#     DOS_tot.append(DOS)
#
# DOS_tot = np.array(DOS_tot).sum(axis=0)
#
# time = np.linspace(0,maxpoint,NO)
# to_plt = (DOS.real**2+DOS.imag**2)**0.5
# plt.plot(time, to_plt)
# plt.xlim([0,200])
# plt.show()

#%% FT to get pho_DOS (numpy)
fig, ax = plt.subplots()

t=np.arange(NT-1)
sp = np.fft.fft(vacf_dat[0]) + np.fft.fft(vacf_dat[1]) + np.fft.fft(vacf_dat[2])
# we are using time -> fs, freq in THz
freq = np.fft.fftfreq(t.shape[-1], d=dT*1E-15)/1E12

# we are actually plotting the square norm of the FT of VACF here
ax.plot(freq, (sp.real**2+sp.imag**2)**0.5,label='MD')
ylim = ax.get_ylim()
ax.vlines(DFT_result,ylim[0],ylim[1], colors='tab:orange',label='DFT')

ax.set_ylim(ylim)
ax.set_xlim([0,200])
ax.set_xlabel('THz')
ax.set_ylabel('Phonon DOS')
ax.legend()
plt.savefig('pho_DOS.png',bbox_inches='tight',dpi=300)
# plt.show()
