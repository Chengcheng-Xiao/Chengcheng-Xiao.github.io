1. `xdat2vdat.pl`
2. `python vacf.py`
