import numpy as np
import matplotlib.pyplot as plt
import sys

#%%
filename = sys.argv[1]
ylim = [-5,5]
E_f  = float(sys.argv[2])
#E_f  = 7.6266

#%%
data = np.loadtxt(filename)

with open(filename, 'r') as f:
    header = f.readline()
nbnd = int(header.strip().split()[-1])
nkpt = int(header.strip().split()[-6])

data = data.reshape([nbnd,nkpt,3])
data[:,:,1] = data[:,:,1]-E_f

#%%
fig, ax = plt.subplots()
for ibnd in range(nbnd):
    ax.plot(data[ibnd,:,0],data[ibnd,:,1], color='tab:blue')
    ax.scatter(data[ibnd,:,0],data[ibnd,:,1],s=500*data[ibnd,:,2],c='tab:red',zorder=100,alpha=0.1)

xticks = []
for ikpt in range(int(nkpt/30+1)):
    xticks.append(data[0,ikpt*30,0])
    ax.vlines(data[0,ikpt*30,0],ylim[0],ylim[1],color='tab:gray',ls='-', alpha=0.8)
# draw hotizontal line for E_fermi
ax.hlines(0, data[0,:,0].min(), data[0,:,0].max(), color='tab:gray',ls='-', alpha=0.8)

# set labels
ax.set_ylim(ylim)
ax.set_ylabel('Energy [eV]')
ax.set_xlim(data[0,:,0].min(), data[0,:,0].max())
ax.set_xticks(xticks)
ax.set_xticklabels([])
#ax.set_ylabel('Energy [eV]')


plt.savefig('test.png')
