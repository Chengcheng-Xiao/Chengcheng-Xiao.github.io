mpiexec pw.x < scf.in | tee  scf.out
mpiexec pw.x < band.in | tee band.out
mpiexec bands.x < bandx.in | tee bandx.out
projwfc.x < proj.in | tee proj.out
python parse.py band.dat.gnu LaRuSi-proj.dat.projwfc_up
python plot.py 7-H-1S.dat 13.2959
