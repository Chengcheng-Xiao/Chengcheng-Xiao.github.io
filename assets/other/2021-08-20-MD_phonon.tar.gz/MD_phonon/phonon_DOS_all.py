import numpy as np

#%%
def get_v_t(step:int):
    interval = 100
    v_t = np.loadtxt('./data_fine/dump.velocity.'+str(step*interval),skiprows=9)
    v_t = v_t[v_t[:, 0].argsort()].reshape([27,8,4])
    v_t = v_t.reshape([27*8,4])[:,1:]

    return v_t

#%% test
# v_t = get_v_t(1000)
# print(v_t.shape)
# print(a[:,0,1].sum())

#%%
def get_v_w(v_t,k):
    '''
    FT[v_t(r)](k)

    we use scaled k and R vecotrs.
    '''
    R_list = np.zeros([27,3])
    indx = 0
    for ix in range(-1,2):
        for iy in range(-1,2):
            for iz in range(-1,2):
                R_list[indx,:] = [ix,iy,iz]
                indx += 1

    v_w = np.zeros([8,3],dtype=complex)
    for iatom in range(8):
        for iR in range(27):
            # print(R_list[iR])
            phase = np.exp(1j*np.dot(k,R_list[iR])*2*np.pi)
            vx = v_t[iR,iatom,1]
            v_w[iatom,0] += vx*phase/np.sqrt(27)
            vy = v_t[iR,iatom,2]
            v_w[iatom,1] += vy*phase/np.sqrt(27)
            vz = v_t[iR,iatom,3]
            v_w[iatom,2] += vz*phase/np.sqrt(27)
    return v_w

#%% test
# v_w = get_v_w(v_t,[0,0,0])
# print(v_w.shape)

#%% get v_w for all time
def get_v_w_all(k):
    '''
    for evergy time step, get the v_w at k point.
    '''
    v_w=[]
    for istep in range(1000,1301):
        v_w_tmp = get_v_t(istep)
        # v_w_tmp = get_v_w(v_t_tmp,k)
        v_w.append(v_w_tmp)

    v_w = np.asarray(v_w)
    # v_w is now [time_step][atom][x,y,z]
    return v_w

#%%
v_w = get_v_w_all(k=[0,0,0])
print(v_w.shape)

#%%
def get_vacf(v_w,t,dt):
    '''
    get velocity autocorrelation function (arb. unit.)
    \sum_{t''} v(t+t')v(t')
    '''
    time_list = v_w.shape[0]
    # assume periodic time boundary and move time axis
    v_w_pt = np.concatenate((v_w[t:],v_w[:t]))
    # we have 300 time points so that we can only use the first 100 points
    vacf_tmp = np.conj(v_w_pt[:101])*v_w[:101]
    # print(vacf_tmp.shape)
    vacf = np.zeros(vacf_tmp.shape[1],dtype=complex)
    for iatom in range(vacf_tmp.shape[1]):
        for itime in range(101):#vacf_tmp.shape[0]):
            vacf[iatom] += np.sum(vacf_tmp[itime,iatom])*dt

    # vacf_0_tmp = v_w*v_w
    # vacf_0 = np.zeros(vacf_0_tmp.shape[1],dtype=complex)
    # for iatom in range(vacf_0_tmp.shape[1]):
    #     for itime in range(vacf_0_tmp.shape[0]):
    #         vacf_0[iatom] += np.sum(vacf_0_tmp[itime,iatom])/vacf_0_tmp.shape[0]
    #
    # vacf /= vacf_0
    # vacf is in [atom]
    return vacf

# def get_vacf(v_w,t,dt):
#     vacf = v_w[0]*v_w[t]
#     vacf = np.sum(vacf,axis=-1)
#     # vacf is in [time_step][atom]
#     return vacf


#%% test
# vacf = get_vacf(v_w,1,0.1)
# print(vacf.shape)


#%% summing up vacf
def sum_vacf(vacf):
    '''
    add up vacf from all atoms
    '''
    vacf_sum = vacf.sum()/len(vacf)
    # vacf_tmp = vacf.copy()
    # vacf_sum = np.zeros(vacf_tmp.shape[0],dtype=complex)
    # for iatom in range(vacf_tmp.shape[0]):
    #     vacf_sum[iatom] = np.sum(vacf[iatom,:])

    return vacf_sum

#%% test
sum_vacf(vacf)

#%%
import sys
def progressbar(it, prefix="", size=60, file=sys.stdout):
    '''
    progress bar function from https://stackoverflow.com/a/34482761
    '''
    count = len(it)
    def show(j):
        x = int(size*j/count)
        file.write("%s[%s%s] %i/%i\r" % (prefix, "#"*x, "."*(size-x), j, count))
        file.flush()
    show(0)
    for i, item in enumerate(it):
        yield item
        show(i+1)
    file.write("\n")
    file.flush()

#-------------------------------------------------------------------------------
#%%
# calculate vacf at different time and k points.
vacf_all = []
for k in np.linspace([0,0,0],[0.5,0,0],1):
    vacf_sum = []
    for itime in progressbar(range(100,201)):
        v_w = get_v_w_all(k)
        vacf = get_vacf(v_w,itime,0.1)
        vacf_sum.append(sum_vacf(vacf))
        # print(itime)
        # vacf_sum=np.asarray(vacf_sum,dtype=complex)
    vacf_all.append(vacf_sum)
vacf_all = np.asarray(vacf_all,dtype=complex)

#%% back-up data
vacf_all_bak = vacf_all.copy()
#%%
vacf_all.shape

#%% calculate the final integral for different k and omega
result = np.zeros([1,1001],dtype=complex)
ik=0
for k in np.linspace([0,0,0],[0.5,0,0],1):
    iomega = 0
    for omega in np.linspace(0,100,1001):
        # omega *= 2*np.pi/100
        for itime in range(101):
            phase = np.exp(-1j*omega*itime)
            result[ik,iomega] += vacf_all[ik,itime] * phase * 0.1
        iomega += 1
    ik+=1

#%%
result.shape

#%% plot
import matplotlib.pyplot as plt
# (result.T)[].shape
# plt.imshow(np.abs(result.T[0:20,:]),origin='lower', aspect='auto')
plt.plot(abs(result[0,:]))
plt.show()
