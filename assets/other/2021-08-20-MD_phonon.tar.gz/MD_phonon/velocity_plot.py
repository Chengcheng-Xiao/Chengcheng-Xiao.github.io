import numpy as np

#%%
def get_v_t(step:int):
    interval = 100
    v_t = np.loadtxt('./data_fine/silicon/dump.velocity.'+str(step*interval),skiprows=9)
    v_t = v_t[v_t[:, 0].argsort()].reshape([27,8,4])

    return v_t

#%%
v_t = []
for i in range(10000):
    v_t.append(get_v_t(i))

v_t = np.asarray(v_t)
#%%
# v_t[0]
#%%
v_1_t = []
for i in range(10000):
    v_1_t.append(np.linalg.norm(v_t[i,0,2,1:]))

v_1_t = np.asarray(v_1_t)
#%%
import matplotlib.pyplot as plt

plt.plot(v_1_t[0:50])
plt.show()
