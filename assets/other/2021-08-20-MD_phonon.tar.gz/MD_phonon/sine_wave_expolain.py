import numpy as np

x = np.linspace(0,4*np.pi,200)

y = np.sin(x)

#%%
import matplotlib.pyplot as plt
plt.plot(x,y)
# plt.show()
plt.savefig('fig1.svg')


#%%
result = []
it = 0
for t in np.linspace(0,4*np.pi,200):
    y1 = np.concatenate((y[it:],y[:it]))
    result.append(y1*y)
    it+=1
#%%
for i in range(0,200,10):
    plt.plot(x,result[i])
# plt.plot(x,result[0])
# plt.plot(x,result[20])
# plt.show()
plt.savefig('fig2.svg')

#%%
result = []
it = 0
for t in np.linspace(0,4*np.pi,200):
    y1 = np.concatenate((y[it:],y[:it]))
    result.append(np.sum(y1*y)*(4*np.pi/200.))
    it+=1
#%%
plt.plot(x,result)
# plt.show()
plt.savefig('fig3.svg')
