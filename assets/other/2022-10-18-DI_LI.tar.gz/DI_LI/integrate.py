from ase.calculators.vasp import VaspChargeDensity
import numpy as np
from vaspwfc import vaspwfc

#a=VaspChargeDensity('BvAt0001.dat.vasp')
CHGCARfile1 = 'BvAt0001.dat.vasp'
CHGCARfile2 = 'BvAt0002.dat.vasp'
WAVECAR     = 'WAVECAR'

# need to find a away to read in this info.
kptw = np.array([1, 8, 4, 6,24,12, 3, 6])
kptw = kptw/kptw.sum()


vasp_charge1 = VaspChargeDensity(filename = CHGCARfile1)
chg1 = vasp_charge1.chg[-1]
atoms1 = vasp_charge1.atoms[-1]
dv1 = atoms1.get_volume()/np.prod(chg1.shape)
del vasp_charge1

vasp_charge2 = VaspChargeDensity(filename = CHGCARfile2)
chg2 = vasp_charge2.chg[-1]
# atoms2 = vasp_charge2.atoms[-1]
# dv2 = atoms2.get_volume()/np.prod(chg2.shape)
del vasp_charge2

# some sanity check
print(f"integrated chage in basin 1: {chg1.sum()*dv1:.5f}")
print(f"integrated chage in basin 2: {chg2.sum()*dv1:.5f}")

# now prepare them for basin integration
chg1[chg1>1e-5]=1; chg1[chg1<1]=0
chg2[chg2>1e-5]=1; chg2[chg2<1]=0

#-------------------------------------------------------------------------------

print('#'+38*'-')
wav = vaspwfc(WAVECAR)


# DI calculation
result = 0
for ikpt in range(1,wav._nkpts+1):
    int = 0
    for iband_i in range(1,2):#wav._nbands):
        for iband_j in range(1,2):#wav._nbands):
            # wav._occ[0,ikpt,iband_i]*
            phi_i = wav.wfc_r(ikpt=ikpt, iband=iband_i, kr_phase=True, ngrid=chg1.shape)/(dv1**0.5)
            phi_j = wav.wfc_r(ikpt=ikpt, iband=iband_j, kr_phase=True, ngrid=chg1.shape)/(dv1**0.5)

            int1 = (phi_i.conj() * phi_j * chg1).sum() * dv1
            int2 = (phi_i * phi_j.conj() * chg2).sum() * dv1
            int += int1*int2
    # print(ikpt, iband_i, iband_j, int)
    result += int*kptw[ikpt-1]
print(f"Calculated DI : {result.real:.5f}")

# LI calculation (basin 1)
result = 0
for ikpt in range(1,wav._nkpts+1):
    int = 0
    for iband_i in range(1,2):#wav._nbands):
        for iband_j in range(1,2):#wav._nbands):
            # wav._occ[0,ikpt,iband_i]*
            phi_i = wav.wfc_r(ikpt=ikpt, iband=iband_i, kr_phase=True, ngrid=chg1.shape)/(dv1**0.5)
            phi_j = wav.wfc_r(ikpt=ikpt, iband=iband_j, kr_phase=True, ngrid=chg1.shape)/(dv1**0.5)

            int1 = (phi_i.conj() * phi_j * chg1).sum() * dv1
            int2 = (phi_i * phi_j.conj() * chg1).sum() * dv1
            int += int1*int2
    # print(ikpt, iband_i, iband_j, int)
    result += int*kptw[ikpt-1]
print(f"Calculated LI (basin 1) : {result.real:.5f}")


# LI calculation (basin 2)
result = 0
for ikpt in range(1,wav._nkpts+1):
    int = 0
    for iband_i in range(1,2):#wav._nbands):
        for iband_j in range(1,2):#wav._nbands):
            # wav._occ[0,ikpt,iband_i]*
            phi_i = wav.wfc_r(ikpt=ikpt, iband=iband_i, kr_phase=True, ngrid=chg1.shape)/(dv1**0.5)
            phi_j = wav.wfc_r(ikpt=ikpt, iband=iband_j, kr_phase=True, ngrid=chg1.shape)/(dv1**0.5)

            int1 = (phi_i.conj() * phi_j * chg2).sum() * dv1
            int2 = (phi_i * phi_j.conj() * chg2).sum() * dv1
            int += int1*int2
    # print(ikpt, iband_i, iband_j, int)
    result += int*kptw[ikpt-1]
print(f"Calculated LI (basin 2) : {result.real:.5f}")
