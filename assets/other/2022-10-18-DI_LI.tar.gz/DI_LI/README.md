
1. run vasp to generate `WAVECAR`, `AECCAR0`, `AECCAR2`, `CHGCAR`.
2. combined `AECCAR0`, `AECCAR2` with `chgsum.pl AECCAR0 AECCAR2`
3. using `CHGCAR_sum` as reference, do bader partition:
```
bader CHGCAR -ref CHGCAR_sum -p all_atom
```
for silicon, we only have to atomic basin, this means we'll only get two LI and one DI.
4. to get LI and DI we need vaspwfc in our `PYTHONPATH`:
```
git clone https://github.com/QijingZheng/VaspBandUnfolding.git
cd VaspBandUnfolding
export PYTHONPATH=$PYTHONPATH:$(pwd)
```
5. run script to generate LI and DI:
```
python integrate.py
```

Alternatively, use the files I've generated:
```
cp output/* .
git clone https://github.com/QijingZheng/VaspBandUnfolding.git
cd VaspBandUnfolding
export PYTHONPATH=$PYTHONPATH:$(pwd)
cd ../
python integrate.py
```
