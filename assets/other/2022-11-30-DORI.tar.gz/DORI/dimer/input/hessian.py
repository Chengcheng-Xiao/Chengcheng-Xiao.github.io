from ase.calculators.vasp import VaspChargeDensity
import numpy as np

#%%
def hessian(potl, delta):
    '''
    Calculate the hessian in direct coordinates

    delta: list : delta along each axis
    potl: np.array: data

    result: np.array : hessian at each point
    '''
    result = np.zeros([3,3]+list(potl.shape))
    for a1 in range(3):
        for a2 in range(3):
            result[a1,a2]=  (np.roll(potl,(-1,-1),axis=(a1,a2))  \
                           - np.roll(potl,(-1,+1),axis=(a1,a2))  \
                           - np.roll(potl,(+1,-1),axis=(a1,a2))  \
                           + np.roll(potl,(+1,+1),axis=(a1,a2))) \
                           / (4*delta[a1]*delta[a2])
    return result

def hess_to_cart(hess, g_mat):
    '''
    convert hessian to cart. coord
    '''
    hess_cart = np.zeros(hess.shape)
    for a in range(3):
        for b in range(3):
            hess_cart[a,b]=np.tensordot(\
                           g_mat[:,b],np.tensordot(g_mat[a,:],hess,axes=(0,0)),\
                           axes=(0,0))
    return hess_cart

#%% read-in data (water dimer)
vasp_charge = VaspChargeDensity(filename = 'CHGCAR')
potl = vasp_charge.chg[-1]
atoms = vasp_charge.atoms[-1]

#%% get recripocal lattice
g_mat = np.linalg.inv(atoms.cell)

#% calculate hessian in direct coordinates
diff = np.divide([1,1,1],potl.shape)
hess = hessian(potl, diff)

#% get hessian matrix in cart. coordinates
hess_cart=hess_to_cart(hess, g_mat)

#%% get the middle eigenvalue at each point (do we have a faster way of doing this?)
final = np.zeros(potl.shape)
for x in range(potl.shape[0]):
    for y in range(potl.shape[1]):
        for z in range(potl.shape[2]):
            final[x,y,z] = np.sort(np.linalg.eig(hess_cart[:,:,x,y,z])[0])[1]

# #%% write hessian
# vasp_charge.chg=[final]
# vasp_charge.write(filename='hess.vasp', format='CHGCAR')

#%% write sign(hess)*rho(r)
vasp_charge.chg=[np.sign(final)*potl]
vasp_charge.write(filename='hess_color.vasp', format='CHGCAR')
