from __future__ import print_function
import numpy as np
from wanSOC.basis import *
from wanSOC.io import *
from wanSOC.helper import *
from wanSOC.hamiltonian import *
import os, re
import matplotlib.pyplot as plt

'''
scripts to reproduce https://www.nature.com/articles/s42005-018-0078-4.pdf
'''

#%% functions to read data
def WeightFromLOCPROJ(infile='LOCPROJ', whichAtom=None):
    """
    Contribution of selected atoms to the each KS orbital
    """

    assert os.path.isfile(infile), '%s cannot be found!' % infile
    FileContents = [line for line in open(infile) if line.strip()]

    # when the band number is too large, there will be no space between ";" and
    # the actual band number. A bug found by Homlee Guo.
    # Here, #kpts, #bands and #ions are all integers
    nspin, nkpts, nbands, nproj = [int(xx) for xx in re.sub(
        '[^0-9]', ' ', FileContents[0]).split()]


    Weights = np.asarray([complex(float(line.split()[1]),float(line.split()[2]))
                          for line in FileContents
                          if not re.search('[a-zA-Z]', line)],
                          dtype=complex)

    # eigenvals = np.zeros([nspin,nkpts,nbands])

    # eigenvals = np.asarray([line.split()[1:] for line in FileContents if re.search('orbital', line)],dtype=float)

    # nspin = Weights.shape[0] // (nkpts * nbands * nions)
    # nspin //= 4 if lsorbit else 1

    # print(Weights.shape)
    # Weights = np.real(np.conj(Weights)*Weights)
    Weights = Weights.reshape(nspin, nkpts, nbands, nproj)

    if whichAtom is None:
        return np.sum(Weights, axis=-1)
    else:
        # whichAtom = [xx - 1 for xx in whichAtom]
        whichAtom = [xx for xx in whichAtom]
        return np.sum(Weights[:, :, :, whichAtom], axis=-1)

def EigenvalsFromLOCPROJ(infile='LOCPROJ'):
    """
    Contribution of selected atoms to the each KS orbital
    """

    assert os.path.isfile(infile), '%s cannot be found!' % infile
    FileContents = [line for line in open(infile) if line.strip()]

    # when the band number is too large, there will be no space between ";" and
    # the actual band number. A bug found by Homlee Guo.
    # Here, #kpts, #bands and #ions are all integers
    nspin, nkpts, nbands, nproj = [int(xx) for xx in re.sub(
        '[^0-9]', ' ', FileContents[0]).split()]


    # Weights = np.asarray([complex(float(line.split()[1]),float(line.split()[2]))
    #                       for line in FileContents
    #                       if not re.search('[a-zA-Z]', line)],
    #                       dtype=complex)

    eigenvals = np.zeros([nspin,nkpts,nbands,2])

    eigenvals_tmp = np.asarray([line.split()[1:] for line in FileContents if re.search('orbital', line)],dtype=float)

    for ispin in range(nspin):
        for ikpt in range(nkpts):
            for ibands in range(nbands):
                eigenvals[ispin,ikpt,ibands,0]=eigenvals_tmp[int(ispin*nkpts*nbands+ikpt*nbands+ibands),3]
                eigenvals[ispin,ikpt,ibands,1]=eigenvals_tmp[int(ispin*nkpts*nbands+ikpt*nbands+ibands),4]

    # nspin = Weights.shape[0] // (nkpts * nbands * nions)
    # nspin //= 4 if lsorbit else 1

    # # print(Weights.shape)
    # # Weights = np.real(np.conj(Weights)*Weights)
    # Weights = Weights.reshape(nspin, nkpts, nbands, nproj)
    #
    # if whichAtom is None:
    #     return np.sum(Weights, axis=-1)
    # else:
    #     # whichAtom = [xx - 1 for xx in whichAtom]
    #     whichAtom = [xx for xx in whichAtom]

    return  eigenvals


#%% generate L matrix
# create lm basis
basis = creat_basis_lm('d')
# create L matrices
Lz = MatLz(basis)
Lp = MatLp(basis)
Lm = MatLm(basis)
# generate transform matrix
trans_L = trans_L_mat('d')
# transform them into real spherical harmonics
Lz = np.dot(np.dot(trans_L.H, Lz),trans_L)
Lp = np.dot(np.dot(trans_L.H, Lp),trans_L)
Lm = np.dot(np.dot(trans_L.H, Lm),trans_L)

#% revert Lp and Lm back to Lz and Lx matrices
# using
Lx = (Lm+Lp)/2
Lz = Lz

#%% get eigenvals and occupation from LOCPROJ
eig = EigenvalsFromLOCPROJ(infile='LOCPROJ')

#%% seperate into occpued and unoccupied [generate masks]
occupied_up = (eig[0,:,:,1]>0)
occupied_dn = (eig[1,:,:,1]>0)

#%% generate projection coeffs from LOCPROJ
# format of the following object spin, kpt, band
dz2    = WeightFromLOCPROJ(infile='LOCPROJ', whichAtom=[2])
dxz    = WeightFromLOCPROJ(infile='LOCPROJ', whichAtom=[3])
dyz    = WeightFromLOCPROJ(infile='LOCPROJ', whichAtom=[1])
dx2_y2 = WeightFromLOCPROJ(infile='LOCPROJ', whichAtom=[4])
dxy    = WeightFromLOCPROJ(infile='LOCPROJ', whichAtom=[0])

#%%
# NOW LETS CALCULATE CONTRIBUTIONS TO MAE FROM DIFFERENT ORBTIALS
#%% up-up components [gamma only]
bands = []
result = []
result_z = []
result_x = []
nband = 20
# for ikpt in range(nkpt):
# unoccupied up channel
for iband in range((occupied_up).sum(),nband):
    # occupied up channel
    for iband_ in range((occupied_up).sum()):
        # put projection coeffes of a band in an array
        bnd = np.array([dz2[0,0,iband],\
                        dxz[0,0,iband],\
                        dyz[0,0,iband],\
                        dx2_y2[0,0,iband],\
                        dxy[0,0,iband]])
        bnd_ = np.array([dz2[0,0,iband_],\
                        dxz[0,0,iband_],\
                        dyz[0,0,iband_],\
                        dx2_y2[0,0,iband_],\
                        dxy[0,0,iband_]])
        # E_unoccupied-E_occupied
        eigdiff = eig[0,0,iband,0] - eig[0,0,iband_,0]
        # band index of the pair
        bands.append([iband, iband_])
        # the resulting MAE contributions
        result.append((np.dot(np.dot(bnd, Lz),bnd_)*\
                 np.conj(np.dot(np.dot(bnd, Lz),bnd_))-\
                         np.dot(np.dot(bnd, Lx),bnd_)*\
                 np.conj(np.dot(np.dot(bnd, Lx),bnd_)))/(eigdiff))
        # <Lz>^2
        result_z.append(np.dot(np.dot(bnd, Lz),bnd_)*\
                 np.conj(np.dot(np.dot(bnd, Lz),bnd_)))
        # <Lx>^2
        result_x.append(np.dot(np.dot(bnd, Lx),bnd_)*\
                 np.conj(np.dot(np.dot(bnd, Lx),bnd_)))
        # result =        np.dot(np.dot(bnd, Lx),bnd_)*\
        #          np.conj(np.dot(np.dot(bnd, Lx),bnd_))
        # print(iband, iband_, result[-1].real[0,0], result_z[-1].real[0,0], result_x[-1].real[0,0])
        # if np.abs(result.real[0,0]) > 1E-1:
        #     print(iband, iband_, result)

#% convert results into array
result = np.array(result).real[:,0,0]
result_z = np.array(result_z).real[:,0,0]
result_x = np.array(result_x).real[:,0,0]

#% Plot Lz
result_z_plot = result_z[result_z > 1E-2]
bands_plot    = np.array(bands)[result_z > 1E-2,:]

fig, ax = plt.subplots(figsize=[3,5])

ax.hlines(eig[0,0,occupied_up[0],0], -1,1)
ax.hlines(eig[0,0,~occupied_dn[0],0], -1,1,color='orange')
ax.hlines(-4.45, -1,1,ls='--')

if len(bands_plot)>0:
    print(bands_plot)
    dx=2/len(bands_plot)
    i = 0
    for pair in bands_plot:
        ax.vlines(-0.8+dx*i,eig[0,0,pair[0],0],eig[0,0,pair[1],0],linewidth=5*result_z_plot[i],antialiased=False,color='red')
        i=i+1


ax.set_ylim([-11,-3])
ax.set_xlim([-1,1])
ax.set_xticks([])
ax.set_xticks([], minor=True)
ax.set_ylabel('Energy [eV]')
plt.show()

#% Plot Lx [just change result_z to result_x]
result_z_plot = result_x[result_x > 1E-2]
bands_plot    = np.array(bands)[result_x > 1E-2,:]

fig, ax = plt.subplots(figsize=[3,5])

ax.hlines(eig[0,0,occupied_up[0],0], -1,1)
ax.hlines(eig[0,0,~occupied_dn[0],0], -1,1,color='orange')
ax.hlines(-4.45, -1,1,ls='--')

if len(bands_plot)>0:
    dx=2/len(bands_plot)
    i = 0
    for pair in bands_plot:
        ax.vlines(-0.8+dx*i,eig[0,0,pair[0],0],eig[0,0,pair[1],0],linewidth=5*result_z_plot[i],antialiased=False,color='red')
        i=i+1


ax.set_ylim([-11,-3])
ax.set_xlim([-1,1])
ax.set_xticks([])
ax.set_xticks([], minor=True)
ax.set_ylabel('Energy [eV]')
plt.show()

#%% dn-dn components [gamma only]
bands = []
result = []
result_z = []
result_x = []
nband = 20
# for ikpt in range(nkpt): # for k dependence
# unoccupied down bands
for iband in range((occupied_dn).sum(),nband):
    # occupied down bands
    for iband_ in range((occupied_dn).sum()):
        # put projection coeffes of a band in an array
        bnd = np.array([dz2[1,0,iband],\
                        dxz[1,0,iband],\
                        dyz[1,0,iband],\
                        dx2_y2[1,0,iband],\
                        dxy[1,0,iband]])
        bnd_ = np.array([dz2[1,0,iband_],\
                        dxz[1,0,iband_],\
                        dyz[1,0,iband_],\
                        dx2_y2[1,0,iband_],\
                        dxy[1,0,iband_]])
        # E_unoccupied-E_occupied
        eigdiff = eig[1,0,iband,0] - eig[1,0,iband_,0]
        # band index of the pair
        bands.append([iband, iband_])
        # resulting MAE contributions
        result.append((np.dot(np.dot(bnd, Lz),bnd_)*\
                 np.conj(np.dot(np.dot(bnd, Lz),bnd_))-\
                         np.dot(np.dot(bnd, Lx),bnd_)*\
                 np.conj(np.dot(np.dot(bnd, Lx),bnd_)))/(eigdiff))
        # <Lz>^2
        result_z.append(np.dot(np.dot(bnd, Lz),bnd_)*\
                 np.conj(np.dot(np.dot(bnd, Lz),bnd_)))
        # <Lx>^2
        result_x.append(np.dot(np.dot(bnd, Lx),bnd_)*\
                 np.conj(np.dot(np.dot(bnd, Lx),bnd_)))
        # result =        np.dot(np.dot(bnd, Lx),bnd_)*\
        #          np.conj(np.dot(np.dot(bnd, Lx),bnd_))
        # print(iband, iband_, result[-1].real[0,0], result_z[-1].real[0,0], result_x[-1].real[0,0])
        # if np.abs(result.real[0,0]) > 1E-1:
        #     print(iband, iband_, result)

#% convert them into array
result = np.array(result).real[:,0,0]
result_z = np.array(result_z).real[:,0,0]
result_x = np.array(result_x).real[:,0,0]

#%% Lz plot
result_z_plot = result_z[abs(result_z) > 1e-3]
bands_plot    = np.array(bands)[abs(result_z) > 1E-3,:]

fig, ax = plt.subplots(figsize=[3,5])

ax.hlines(eig[1,0,occupied_up[0],0], -1,1)
ax.hlines(eig[1,0,~occupied_dn[0],0], -1,1,color='orange')
ax.hlines(-4.45, -1,1,ls='--')

dx=2/len(bands_plot)
i = 0
for pair in bands_plot:
    ax.vlines(-0.8+dx*i, eig[1,0,pair[0],0],eig[1,0,pair[1],0],linewidth=5*result_z_plot[i],antialiased=False,color='red')
    i=i+1

ax.set_ylim([-11,-3])
ax.set_xlim([-1,1])
ax.set_xticks([])
ax.set_xticks([], minor=True)
ax.set_ylabel('Energy [eV]')
# plt.savefig('Lz-dn-dn.svg',bbox_inches='tight')
plt.show()

#%% Lx plot
result_z_plot = result_x[abs(result_x) > 1e-3]
bands_plot    = np.array(bands)[abs(result_x) > 1E-3,:]

fig, ax = plt.subplots(figsize=[3,5])

ax.hlines(eig[1,0,occupied_up[0],0], -1,1)
ax.hlines(eig[1,0,~occupied_dn[0],0], -1,1,color='orange')
ax.hlines(-4.45, -1,1,ls='--')

dx=2/len(bands_plot)
i = 0
for pair in bands_plot:
    ax.vlines(-0.8+dx*i, eig[1,0,pair[0],0],eig[1,0,pair[1],0],linewidth=5*result_z_plot[i],antialiased=False,color='red')
    i=i+1

ax.set_ylim([-11,-3])
ax.set_xlim([-1,1])
ax.set_xticks([])
ax.set_xticks([], minor=True)
ax.set_ylabel('Energy [eV]')
# plt.savefig('Lx-dn-dn.svg',bbox_inches='tight')
plt.show()

#%% dn-up components [gamma only, put in to list]
bands = []
result = []
result_z = []
result_x = []
nband = 20
# for ikpt in range(nkpt):
# unoccupied down bands
for iband in range((occupied_dn).sum(),nband):
    # occupied up bands
    for iband_ in range((occupied_up).sum()):
        # put projection coeffes of a band in an array
        bnd = np.array([dz2[1,0,iband],\
                        dxz[1,0,iband],\
                        dyz[1,0,iband],\
                        dx2_y2[1,0,iband],\
                        dxy[1,0,iband]])
        bnd_ = np.array([dz2[0,0,iband_],\
                        dxz[0,0,iband_],\
                        dyz[0,0,iband_],\
                        dx2_y2[0,0,iband_],\
                        dxy[0,0,iband_]])
        # E_unoccupied-E_occupied
        eigdiff = eig[1,0,iband,0] - eig[0,0,iband_,0]
        # band index of the pair
        bands.append([iband, iband_])
        # resulting MAE contributions
        result.append((np.dot(np.dot(bnd, Lz),bnd_)*\
                 np.conj(np.dot(np.dot(bnd, Lz),bnd_))-\
                         np.dot(np.dot(bnd, Lx),bnd_)*\
                 np.conj(np.dot(np.dot(bnd, Lx),bnd_)))/(eigdiff))
        # <Lz>^2
        result_z.append(np.dot(np.dot(bnd, Lz),bnd_)*\
                 np.conj(np.dot(np.dot(bnd, Lz),bnd_)))
        # <Lz>^2
        result_x.append(np.dot(np.dot(bnd, Lx),bnd_)*\
                 np.conj(np.dot(np.dot(bnd, Lx),bnd_)))
        # result =        np.dot(np.dot(bnd, Lx),bnd_)*\
        #          np.conj(np.dot(np.dot(bnd, Lx),bnd_))
        # print(iband, iband_, result[-1].real[0,0], result_z[-1].real[0,0], result_x[-1].real[0,0])
        # if np.abs(result.real[0,0]) > 1E-1:
        #     print(iband, iband_, result)
        # print(result.real[0,0])

result = np.array(result).real[:,0,0]
result_z = np.array(result_z).real[:,0,0]
result_x = np.array(result_x).real[:,0,0]

#%% Lz plot
result_z_plot = result_z[abs(result_z) > 1e-3]
bands_plot    = np.array(bands)[abs(result_z) > 1E-3,:]

fig, ax = plt.subplots(figsize=[3,5])

ax.hlines(eig[0,0,occupied_up[0],0], -1,1)
ax.hlines(eig[1,0,~occupied_dn[0],0], -1,1,color='orange')
ax.hlines(-4.45, -1,1,ls='--')

dx=2/len(bands_plot)
i = 0
for pair in bands_plot:
    ax.vlines(-0.8+dx*i, eig[1,0,pair[0],0],eig[0,0,pair[1],0],linewidth=5*result_z_plot[i],antialiased=False,color='red')
    i=i+1

ax.set_ylim([-11,-3])
ax.set_xlim([-1,1])
ax.set_xticks([])
ax.set_xticks([], minor=True)
ax.set_ylabel('Energy [eV]')
plt.show()

#%% Lx plot
result_z_plot = result_x[abs(result_x) > 1e-2]
bands_plot    = np.array(bands)[abs(result_x) > 1E-2,:]

fig, ax = plt.subplots(figsize=[3,5])

ax.hlines(eig[0,0,occupied_up[0],0], -1,1)
ax.hlines(eig[1,0,~occupied_dn[0],0], -1,1,color='orange')
ax.hlines(-4.45, -1,1,ls='--')

dx=2/len(bands_plot)
i = 0
for pair in bands_plot:
    ax.vlines(-0.8+dx*i, eig[1,0,pair[0],0],eig[0,0,pair[1],0],linewidth=5*result_z_plot[i],antialiased=False,color='red')
    i=i+1

ax.set_ylim([-11,-3])
ax.set_xlim([-1,1])
ax.set_xticks([])
ax.set_xticks([], minor=True)
ax.set_ylabel('Energy [eV]')
plt.show()
