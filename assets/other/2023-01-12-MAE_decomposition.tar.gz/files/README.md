1. For VASP to output projection coeffs using PAW projectors without using the core chagres as the weighting facto, apply the patch (`LOCPROJ_coeff.patch`) to VASP 5.4.4, recompile it.
2. run vasp, make sure you are using the correct projection channel with PAW projectors (see `LOCPROJ` in `INCAR`).
3. run `MAE_decompose.py`, check out the details inside.
