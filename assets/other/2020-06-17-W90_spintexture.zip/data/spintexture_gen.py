#!/usr/bin/env python

from pythtb import * # import TB model class
import matplotlib.pyplot as plt

# read output from Wannier90 that should be in folder named "example_a"
#   see instructions above for how to obtain the example output from
#   Wannier90 for testing purposes
InSe=w90(r"output/wannier90",r"wannier90")

# get tight-binding model without hopping terms above 0.01 eV
my_model=InSe.model()
#%% k_mesh parameters
ksize_x = 21
ksize_y = 21
krange = 1.0
origin = [-krange/2,-krange/2]
# k_vec = my_model.k_uniform_mesh([ksize_x,ksize_y,1])
# (evals,evacs)=my_model.solve_all(k_vec,eig_vectors=True)
#%% set up k grid
k_vec = np.empty([(ksize_x)*(ksize_y),3])
for a in range(ksize_x):
    for b in range(ksize_y):
        k_vec[a*ksize_x+b]=[origin[0]+a*(krange/ksize_x),origin[1]+b*(krange/ksize_y),0.0]

# or use automatic generation (1st BZ, 1st quadrant only)
# k_vec = my_model.k_uniform_mesh([ksize_x,ksize_y,1])
(evals,evacs)=my_model.solve_all(k_vec,eig_vectors=True)
#%% check evals and k_vec ?
# print k_vec[20]
# print evals.reshape(22,ksize_x,ksize_y).swapaxes(1,2)[16,0,20]
#%% reordering everything
# reorder kpoints
k_vec_new = k_vec.reshape(ksize_x,ksize_y,3)
# reorder evacs, need to swap axis to fortran like...
evacs_new = evacs.reshape(22,ksize_y,ksize_x,22).swapaxes(1,2)
# reorder evals, need to swap axis to fortran like...
evals_new = evals.reshape(22,ksize_x,ksize_y).swapaxes(1,2)
#%% get me spin expectatin value, see pauli matrix... duh.
nband = 16 # check band structure to see which band you want.... duh.
exp = np.empty([ksize_x,ksize_y,3],dtype=np.complex)
for a in range(ksize_x):
    for b in range(ksize_y):
        # for non-sprcified non-collinear spin channels, we use default order (orb1_up, orb1_down, orb2_up, orb2_down..)
        # this default order only works with Wannier90 v2.1.0+
        exp[a,b,0] = np.dot(np.conjugate(evacs_new[nband,a,b,0::2]),complex(+1,0)*evacs_new[nband,a,b,1::2])\
                   + np.dot(np.conjugate(evacs_new[nband,a,b,1::2]),complex(+1,0)*evacs_new[nband,a,b,0::2])
        exp[a,b,1] = np.dot(np.conjugate(evacs_new[nband,a,b,0::2]),complex(0,-1)*evacs_new[nband,a,b,1::2])\
                   + np.dot(np.conjugate(evacs_new[nband,a,b,1::2]),complex(0,+1)*evacs_new[nband,a,b,0::2])
        exp[a,b,2] = np.dot(np.conjugate(evacs_new[nband,a,b,0::2]),complex(+1,0)*evacs_new[nband,a,b,0::2])\
                   + np.dot(np.conjugate(evacs_new[nband,a,b,1::2]),complex(-1,0)*evacs_new[nband,a,b,1::2])
#%% check expectation value ?
# print k_vec_new[11,11]
# print exp[10,0,0], exp[10,0,1], exp[10,0,2]
# print origin[0],krange/2,krange/ksize_x
#%% plot spin texture
import matplotlib.transforms as mtransforms

fig, ax = plt.subplots()
# get tran_data function, this will slightly change the direction of the spin vector, but quantitavely its alrigh.
trans_data = mtransforms.Affine2D().skew_deg(-15, -15).rotate_deg(-15) + ax.transData

x = np.arange(origin[0],krange/2.,krange/ksize_x)
y = np.arange(origin[1],krange/2.,krange/ksize_y)

# M = exp[:,:,2].astype('float64') # use sigma_z as color map
M = evals_new[nband,:,:] # use eigenval as color map

im = ax.quiver(x,y,exp[:,:,0],exp[:,:,1],M, scale=13,pivot='mid',transform = trans_data)
# ax.axis([origin[0],krange/2,origin[1],krange/2])
ax.set_aspect('equal')
ax.set_title("band# "+str(nband))
plt.savefig("spintexture_band_"+str(nband)+".png", dpi=300)
# plt.show()
# %% plot fermi surface [or 3D band surface]
import matplotlib.transforms as mtransforms

fig, ax = plt.subplots()
im = ax.imshow(evals_new[17,:,:],
               extent=[origin[0],krange/2,origin[1],krange/2],
               aspect=1,interpolation='lanczos',origin='lower')
# skew and rotate to match k vectors.
trans_data = mtransforms.Affine2D().skew_deg(-15, -15).rotate_deg(-15) + ax.transData
im.set_transform(trans_data)
# reset axes limit
x1, x2, y1, y2 = im.get_extent()
ax.plot([x1, x2, x2, x1, x1], [y1, y1, y2, y2, y1], "-",
        transform=trans_data)

ax.set_title("band# "+str(nband))
plt.savefig("fermi_surface_band_"+str(nband)+".png", dpi=300)
# plt.show()
#%% solve model on a path
# path=[[0.0,0.0,0.0], [-0.25,0.25,0.0],[0.0,0.0,0.0],[0.25,0.25,0.0]]#,[1./3.,1./3.,0.0]]
# # labels of the nodes
# k_label=(r'$\Gamma$',r'$X$', r'$M$', r'$\Gamma$')
# # call function k_path to construct the actual path
# (k_vec_band,k_dist,k_node)=my_model.k_path(path,51)
#
# evals_band=my_model.solve_all(k_vec_band)
# %% plot band
# fig, ax = plt.subplots()
# for i in range(evals.shape[0]):
#     ax.plot(k_dist,evals_band[i],"k-")
# for n in range(len(k_node)):
#     ax.axvline(x=k_node[n],linewidth=0.5, color='k')
# ax.set_xlabel("Path in k-space")
# ax.set_ylabel("Band energy (eV)")
# ax.set_xlim(k_dist[0],k_dist[-1])
# ax.set_ylim(-3.1,-2.5)
# ax.set_xticks(k_node)
# ax.set_xticklabels(k_label)
# fig.tight_layout()
# fig.show()
