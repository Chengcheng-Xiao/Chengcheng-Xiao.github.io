import pyprocar
pyprocar.repair('output/VASP/PROCAR')
pyprocar.fermi2D('output/VASP/PROCAR-repaired', outcar='output/VASP/OUTCAR', st=True, energy=-0.14, noarrow=False, spin=1, code='vasp')
