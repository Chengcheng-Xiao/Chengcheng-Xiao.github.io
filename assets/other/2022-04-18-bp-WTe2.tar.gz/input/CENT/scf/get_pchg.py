from pymatgen.io.vasp.outputs import Eigenval
from pymatgen.electronic_structure.core import Spin
import numpy as np

NBND_OCC = 104
EFERMI   = 6.4529322274

eig = Eigenval('EIGENVAL')
eigval = eig.eigenvalues[(Spin.up)]

print('#kpt hole_band elect_band')
for kpt in range(eigval.shape[0]):
    print(f"{kpt} {np.where((eigval[kpt,:NBND_OCC,0]>EFERMI)==True)[0]+1} {np.where((eigval[kpt,NBND_OCC:,0]<EFERMI)==True)[0]+1}")
