# WTe2 polar metal polarization calculation

1. optimize geometry: `CENT/opt` and `FE/opt`.
2. calculate polraization with fixed occupation: `polarization`.
3. calculate the conduction chage polarization: `CENT/scf` and `FE/scf`.

Result are stored in result.xlsx

The polarization of the conduction charge is not calculate because it's too small.
