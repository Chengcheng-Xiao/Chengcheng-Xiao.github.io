from ase.calculators.vasp import VaspChargeDensity
import numpy as np
import matplotlib.pyplot as plt

#%%
import matplotlib as mpl
# use the following to reset style
mpl.rcParams.update(mpl.rcParamsDefault)

# use mystyle and set dpi to 300
plt.style.use('publication')
mpl.rcParams['figure.dpi']= 300


#%%
def gradient(potl, delta):
    '''
    Calculate the gradient of potl at each point
    '''
    result = np.zeros([3]+list(potl.shape))
    da = (np.roll(potl,-1,0)-np.roll(potl,1,0))/delta[0]
    db = (np.roll(potl,-1,1)-np.roll(potl,1,1))/delta[1]
    dc = (np.roll(potl,-1,2)-np.roll(potl,1,2))/delta[2]
    result[0,:]=da
    result[1,:]=db
    result[2,:]=dc
    # result = np.sqrt(da**2+db**2+dc**2)
    return result

def grad_rho_to_cart_abs(grad_rho, g_mat):
    '''
    transform grad_rho to cart coord and take the mod of it at each point.
    '''
    grad_rho_cart = np.zeros(grad_rho.shape)
    for a in range(3):
        grad_rho_cart[a]=np.tensordot(g_mat[:,a],grad_rho,axes=(0,0))
    grad_rho_abs = np.sqrt(grad_rho_cart[0]**2+grad_rho_cart[1]**2+grad_rho_cart[2]**2)
    return grad_rho_abs


#%% read-in data (water dimer)
vasp_charge = VaspChargeDensity(filename = 'CHGCAR_bicylo')
potl = vasp_charge.chg[-1]
atoms = vasp_charge.atoms[-1]

#% calculate hessian in direct coordinates
diff = np.divide([1,1,1],potl.shape)

#% get recripocal lattice
g_mat = np.linalg.inv(atoms.cell)

#% now calculate the reduced gradient density.
grad_rho = gradient(potl, diff)
grad_rho_abs = grad_rho_to_cart_abs(grad_rho, g_mat)

#% calculate the reduced gradient density
reduced_grad_rho_double = 1/(2*(2*np.pi**2)**(1/3))*grad_rho_abs/potl**(4/3)
potl_double = potl.copy()

#%% flatten the data for plot
rdg_double = reduced_grad_rho_double.copy().flatten()
chg_double = potl_double.copy().flatten()

#%% plot
fig, ax = plt.subplots(figsize=[5,4])
ax.scatter(np.sort(chg_double), rdg_double[chg_double.argsort()],label='Dimer')
ax.set_ylim([0,2])
#ax.set_xlim([0,1.3])
ax.set_xlabel(r'$\mathrm{\rho}$')
ax.set_ylabel('Reduced Density Gradient')
ax.legend(loc='upper right')
plt.tight_layout()
plt.savefig('reduced_density_gradient.png')
#plt.show()

#%% save to file for plot using VASP
# Now we see that there's a clear peak with low density but low RDG as well
# Plotting it suggests that it is the hydrogen bond.

to_file = reduced_grad_rho_double.copy()
potl_to_file = potl_double.copy()

#% invert logic
# https://stackoverflow.com/questions/13728708/inverting-a-numpy-boolean-array-using
# ~((to_file<1.6)*(potl_to_file<0.75))

#% plot to file
to_file = reduced_grad_rho_double.copy()
to_file[~((to_file<1.2)*(potl_to_file<0.3))] = 0
vasp_charge.chg=[to_file]
#vasp_charge.atoms = [atom_double]
vasp_charge.write(filename='rdg.vasp', format='CHGCAR')
