import re
import numpy as np
import matplotlib.pyplot as plt

#%%
def get_v_t(step:int):
    interval = 1
    v_t = np.loadtxt('./dump/dump.velocity.'+str(step*interval),skiprows=9)
    v_t = v_t[v_t[:, 0].argsort()].reshape([27,8,4])
    # v_t = v_t[:,:,1:]

    return v_t

#%% test
# v_t = get_v_t(0)
# print(v_t.shape)
# v_t[0,0]
# print(a[:,0,1].sum())

#%%
def get_v_w(v_t,k):
    '''
    FT[v_t(r)](k)

    we use scaled k and R vecotrs.
    '''
    R_list = np.zeros([27,3])
    indx = 0
    for ix in range(-1,2):
        for iy in range(-1,2):
            for iz in range(-1,2):
                R_list[indx,:] = [ix,iy,iz]
                indx += 1

    v_w = np.zeros([8,3],dtype=complex)
    for iatom in range(8):
        for iR in range(27):
            phase = np.exp(1j*np.dot(k,R_list[iR])*2*np.pi)
            vx = v_t[iR,iatom,1]
            v_w[iatom,0] += vx*phase/np.sqrt(27)
            vy = v_t[iR,iatom,2]
            v_w[iatom,1] += vy*phase/np.sqrt(27)
            vz = v_t[iR,iatom,3]
            v_w[iatom,2] += vz*phase/np.sqrt(27)
    return v_w
#%% FT from real space to k space
v_k_t = []
for time in range(8000):
    v_R_t = get_v_t(time)
    v_k_t.append(get_v_w(v_R_t,[0.5,0,0]))

#%
v_k_t = np.array(v_k_t)
#%
data = v_k_t
#%% read-in velocity (Å/fs)
# with open('VDATCAR', 'r') as f:
#     orig_data=f.readlines()
#
# tmp = [line for line in orig_data if line.strip()]
# data = np.array([line.strip().split() for line in tmp[8:] \
#                  if not re.search('[a-zA-Z]', line)],dtype=float)

#%% input
NATM = 8    # number of atoms
NT   = 8000 # number of MD runs
dT   = 1  # timestep [in fs]


#%% get VACF
def autocorr(x):
    '''
    numpy's correlation method
    see: https://stackoverflow.com/a/676302/12660859
    '''
    result = np.correlate(x, x, mode='full')
    return result[len(x)-1:]

def vacf(data, t, atm):
    '''
    manually calculate VCAF
    this routine gives more flexibility to perform dot product in 3D space.
    '''
    data1 = np.zeros(data.shape,dtype=complex)
    data1[:data.shape[0]-t] = data[t:]
    # perform dot product to get vacf for each atom
    return (data[:,atm,:]*data1[:,atm,:]).sum(axis=-1).sum(axis=-1)


#%% append all vacf for each data
# vacf_dat = [[]]*NATM
vacf_dat=[[],[],[],[],[],[],[],[]]
for time in range(NT):
    # print(time)
    for atm in range(NATM):
        vacf_dat[atm].append(vacf(data, time, atm))
#
vacf_dat = np.array(vacf_dat)


#%% FT to get pho_DOS (numpy)
fig, ax = plt.subplots()

t=np.arange(NT)
sp = np.fft.fft(vacf_dat[0]) + np.fft.fft(vacf_dat[1]) + np.fft.fft(vacf_dat[2])
# we are using time -> fs, freq in THz
freq = np.fft.fftfreq(t.shape[-1], d=dT*1E-15)/1E12

# we are actually plotting the square norm of the FT of VACF here
ax.plot(freq, (sp.real**2+sp.imag**2)**0.5,label='MD')
ylim = ax.get_ylim()
# ax.vlines(DFT_result,ylim[0],ylim[1], colors='tab:orange',label='DFT')

ax.set_ylim(ylim)
ax.set_xlim([0,30])
ax.set_xlabel('THz')
ax.set_ylabel('Phonon DOS')
ax.legend()
# plt.savefig('pho_DOS.png',bbox_inches='tight',dpi=300)
plt.show()
